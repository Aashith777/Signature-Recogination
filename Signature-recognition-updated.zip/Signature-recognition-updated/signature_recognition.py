"""
Offline Signature Recognition using a CNN.

Expected training layout:
data/train/
    A/
        image1.png
    B/
        image2.png

Test images belong in data/test/. The original CNN-based approach is retained;
this version modernizes paths, preprocessing, training, and prediction.
"""

from pathlib import Path
import argparse
import numpy as np
import pandas as pd
from PIL import Image

from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder
from sklearn.metrics import accuracy_score, classification_report

import tensorflow as tf
from tensorflow.keras import layers, models, callbacks


ROOT_DIR = Path(__file__).resolve().parent
TRAIN_DIR = ROOT_DIR / "data" / "train"
TEST_DIR = ROOT_DIR / "data" / "test"
MODEL_DIR = ROOT_DIR / "models"
OUTPUT_DIR = ROOT_DIR / "outputs"

IMAGE_HEIGHT = 190
IMAGE_WIDTH = 160
IMAGE_CHANNELS = 3
RANDOM_STATE = 23
SUPPORTED_FORMATS = {".png", ".jpg", ".jpeg", ".bmp", ".tif", ".tiff"}


def load_image(image_path):
    """Read an image, convert it to RGB, resize it, and scale pixels to [0, 1]."""
    with Image.open(image_path) as image:
        image = image.convert("RGB")
        image = image.resize((IMAGE_WIDTH, IMAGE_HEIGHT))
        return np.asarray(image, dtype=np.float32) / 255.0


def load_training_data():
    """Load images from class-named folders inside data/train."""
    if not TRAIN_DIR.exists():
        raise FileNotFoundError(
            f"Training folder not found: {TRAIN_DIR}\n"
            "Create data/train/<class_name>/ and add signature images."
        )

    image_data, labels = [], []
    class_dirs = sorted(path for path in TRAIN_DIR.iterdir() if path.is_dir())

    if not class_dirs:
        raise ValueError("No class folders found inside data/train.")

    for class_dir in class_dirs:
        image_files = sorted(
            path for path in class_dir.iterdir()
            if path.is_file() and path.suffix.lower() in SUPPORTED_FORMATS
        )
        if not image_files:
            print(f"Skipping '{class_dir.name}': no supported images found.")
            continue

        for image_path in image_files:
            try:
                image_data.append(load_image(image_path))
                labels.append(class_dir.name)
            except (OSError, ValueError) as error:
                print(f"Could not read {image_path.name}: {error}")

        print(f"Loaded {len(image_files)} image(s) from {class_dir.name}")

    if not image_data:
        raise ValueError("No readable training images were found.")

    return np.asarray(image_data, dtype=np.float32), np.asarray(labels)


def build_cnn(number_of_classes):
    """Build the same three-block CNN-style signature classifier."""
    model = models.Sequential([
        layers.Input(shape=(IMAGE_HEIGHT, IMAGE_WIDTH, IMAGE_CHANNELS)),
        layers.Conv2D(64, (3, 3), padding="same", activation="relu"),
        layers.Conv2D(64, (3, 3), padding="valid", activation="relu"),
        layers.ZeroPadding2D(padding=(1, 1)),
        layers.MaxPooling2D(pool_size=(2, 2), strides=(2, 2)),
        layers.Dropout(0.25),

        layers.Conv2D(96, (3, 3), padding="same", activation="relu"),
        layers.Conv2D(96, (3, 3), padding="valid", activation="relu"),
        layers.ZeroPadding2D(padding=(1, 1)),
        layers.MaxPooling2D(pool_size=(2, 2), strides=(2, 2)),
        layers.Dropout(0.25),

        layers.Conv2D(128, (2, 2), padding="same", activation="relu"),
        layers.Conv2D(128, (2, 2), padding="same", activation="relu"),
        layers.MaxPooling2D(pool_size=(2, 2), strides=(2, 2)),
        layers.Dropout(0.25),

        layers.Flatten(),
        layers.Dense(1024, activation="relu"),
        layers.Dropout(0.5),
        layers.Dense(number_of_classes, activation="softmax"),
    ])

    model.compile(
        optimizer=tf.keras.optimizers.Adam(learning_rate=0.0001),
        loss="sparse_categorical_crossentropy",
        metrics=["accuracy"],
    )
    return model


def train_model(epochs=10, batch_size=32):
    images, labels = load_training_data()
    encoder = LabelEncoder()
    encoded_labels = encoder.fit_transform(labels)

    class_counts = np.bincount(encoded_labels)
    stratify_labels = encoded_labels if np.min(class_counts) >= 2 else None

    x_train, x_valid, y_train, y_valid = train_test_split(
        images,
        encoded_labels,
        test_size=0.2,
        random_state=RANDOM_STATE,
        stratify=stratify_labels,
    )

    model = build_cnn(len(encoder.classes_))
    model.summary()

    MODEL_DIR.mkdir(exist_ok=True)
    OUTPUT_DIR.mkdir(exist_ok=True)

    stop_early = callbacks.EarlyStopping(
        monitor="val_loss", patience=4, restore_best_weights=True
    )
    save_best = callbacks.ModelCheckpoint(
        MODEL_DIR / "signature_model.keras",
        monitor="val_loss",
        save_best_only=True,
    )

    model.fit(
        x_train,
        y_train,
        validation_data=(x_valid, y_valid),
        epochs=epochs,
        batch_size=batch_size,
        shuffle=True,
        callbacks=[stop_early, save_best],
    )

    predictions = np.argmax(model.predict(x_valid, verbose=0), axis=1)
    print("\nValidation accuracy:", round(accuracy_score(y_valid, predictions), 4))
    print(classification_report(
        y_valid, predictions,
        labels=np.arange(len(encoder.classes_)),
        target_names=encoder.classes_,
        zero_division=0,
    ))

    np.save(MODEL_DIR / "class_names.npy", encoder.classes_)
    return model, encoder


def predict_test_images():
    model_path = MODEL_DIR / "signature_model.keras"
    class_path = MODEL_DIR / "class_names.npy"

    if not model_path.exists() or not class_path.exists():
        raise FileNotFoundError("Train the model first using: python signature_recognition.py --train")

    if not TEST_DIR.exists():
        raise FileNotFoundError(f"Test folder not found: {TEST_DIR}")

    model = tf.keras.models.load_model(model_path)
    class_names = np.load(class_path, allow_pickle=False)
    test_files = sorted(
        path for path in TEST_DIR.iterdir()
        if path.is_file() and path.suffix.lower() in SUPPORTED_FORMATS
    )

    if not test_files:
        raise ValueError("No test images found in data/test.")

    images, valid_files = [], []
    for image_path in test_files:
        try:
            images.append(load_image(image_path))
            valid_files.append(image_path)
        except (OSError, ValueError) as error:
            print(f"Skipping {image_path.name}: {error}")

    probabilities = model.predict(np.asarray(images), verbose=0)
    predicted_indices = np.argmax(probabilities, axis=1)
    confidence = np.max(probabilities, axis=1)

    results = pd.DataFrame({
        "image": [path.name for path in valid_files],
        "predicted_class": class_names[predicted_indices],
        "confidence": np.round(confidence, 4),
    })

    OUTPUT_DIR.mkdir(exist_ok=True)
    output_file = OUTPUT_DIR / "signature_results.csv"
    results.to_csv(output_file, index=False)
    print(results.to_string(index=False))
    print(f"\nResults saved to: {output_file}")


def main():
    parser = argparse.ArgumentParser(description="CNN-based offline signature recognition")
    parser.add_argument("--train", action="store_true", help="Train the CNN model")
    parser.add_argument("--predict", action="store_true", help="Predict images in data/test")
    parser.add_argument("--epochs", type=int, default=10)
    parser.add_argument("--batch-size", type=int, default=32)
    args = parser.parse_args()

    if args.train:
        train_model(epochs=args.epochs, batch_size=args.batch_size)
    if args.predict:
        predict_test_images()
    if not args.train and not args.predict:
        parser.print_help()


if __name__ == "__main__":
    main()
