# CNN-Based Signature Recognition

An updated version of the original offline signature-recognition project.

## What changed
- Kept the original CNN-based recognition approach and its three convolution blocks.
- Replaced machine-specific Windows paths with portable project-relative paths.
- Updated image loading to use Pillow and consistent RGB preprocessing.
- Added command-line options for training and prediction.
- Added early stopping and best-model checkpoint saving.
- Added predicted class and confidence output in a CSV file.
- Updated the code to use current TensorFlow/Keras APIs.

## Project structure

```text
Signature-recognition-updated/
├── data/
│   ├── train/
│   │   ├── A/
│   │   ├── B/
│   │   └── ... one folder per signature class
│   └── test/
├── models/
├── outputs/
├── signature_recognition.py
└── requirements.txt
```

Place training images inside class-named folders. For example, all images belonging
to class `A` go in `data/train/A/`. Put images to classify in `data/test/`.

## Setup

Python 3.10 or 3.11 is recommended.

```bash
python -m venv .venv
```

Activate the environment:

**Windows**
```bash
.venv\Scripts\activate
```

**macOS/Linux**
```bash
source .venv/bin/activate
```

Install packages:

```bash
pip install -r requirements.txt
```

## Train

```bash
python signature_recognition.py --train
```

Optional training settings:

```bash
python signature_recognition.py --train --epochs 15 --batch-size 32
```

The trained model and class names are saved in `models/`.

## Predict

After training, put images in `data/test/` and run:

```bash
python signature_recognition.py --predict
```

Predictions are saved to `outputs/signature_results.csv`.

## Important
The ZIP supplied with the original project did not include the training dataset.
Add your own labelled training images before running training. Each class should
contain enough images for a useful train/validation split.

This project performs offline image-based signature classification. It is a
demonstration and should not be treated as proof of identity or as a security
or authentication system.
